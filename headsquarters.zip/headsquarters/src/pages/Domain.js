import { Header } from "../components/header/Header";
import { Footer } from "../components/footer/Footer";
import { Cta } from "../components/cta/Cta";
import { CardComponent } from "../components/cards/CardComponent";
import { Hero } from "../components/hero/Hero";
import { FaqComponent } from "../components/faq/FaqComponent";

import domainFeatures from "./../api/domain-features.json";
import faq from "./../api/faq.json";
import { Hosting } from "./Hosting";
import { Tips } from "../widgets/tips/Tips";

export const Domain = () => (
  <>
    <Header />
    <Hero />
    <Hosting />
    <Tips />
    <CardComponent
      title="Get a ton more out of your domain in Headsquarters"
      data={domainFeatures}
      type="alt"
    />
    <FaqComponent
      title="Got questions about domain? Well, we've got answers"
      data={faq}
    />
    <Cta />
    <Footer />
  </>
);
