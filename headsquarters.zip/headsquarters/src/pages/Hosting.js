import { Header } from "../components/header/Header";
import { Footer } from "../components/footer/Footer";
import { Cta } from "../components/cta/Cta";
// import { CardComponent } from "../components/cards/CardComponent";

// import domainFeatures from "./../api/domain-features.json";
// import { Hero } from "../components/hero/Hero";

export const Hosting = () => (
  <>
    <Header />
    <Cta />
    <Footer />
  </>
);
