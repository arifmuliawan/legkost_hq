import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import { Homepage } from "./pages/Homepage";
import { Domain } from "./pages/Domain";
import { NotFound } from "./pages/NotFound";

export const Routing = () => (
  <Router>
    <Routes>
      <Route path="/" element={<Homepage />} />
      <Route path="/domain" element={<Domain />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  </Router>
);
